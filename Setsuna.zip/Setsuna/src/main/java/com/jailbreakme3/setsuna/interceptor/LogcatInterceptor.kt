package com.jailbreakme3.setsuna.interceptor

import android.util.Log
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

class LogcatInterceptor(private val logger: Logger = Logger.DEFAULT) : Interceptor {

    interface Logger {
        fun log(message: String)

        companion object {
            /** A [Logger] defaults output appropriate for the current platform.  */
            val DEFAULT: Logger = object : Logger {
                override fun log(message: String) {
                    Log.i("LogcatInterceptor", message, null)
                }
            }
        }
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val requestId = request.headers().get("X-Request-Id") ?: "null"
        val url = request.url()
        logger.log("Start Request URL = $url")
        logger.log("X-Request-Id = $requestId")
        logger.log("x-snbps-cplc = ${request.headers().get("x-snbps-cplc")}")

        val startNs = System.nanoTime()
        val response = chain.proceed(request)
        val tookMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNs)

        logger.log("response-code = ${response.code()}")
        logger.log("response-message = ${response.message()}")
        logger.log("End Request URL = $url ($tookMs ms)")
        return response
    }
}