package com.jailbreakme3.setsuna

enum class RequestType {
    GET, POST, PUT, DELETE
}