package com.jailbreakme3.setsuna.ednetwork

class HttpDeResponse<out T>(val code: Int, val message: String? = "", val data: T?) {
    /**
     * 接口返回成功
     */
    fun isSuccessful(): Boolean {
        return code == 0x0
    }
}