package com.jailbreakme3.setsuna.interceptor


import android.util.Base64
import com.jailbreakme3.setsuna.ednetwork.EDWhitePath
import com.jailbreakme3.setsuna.ednetwork.EncryptionDecryptionApi
import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.ResponseBody
import org.json.JSONObject
import java.nio.charset.Charset

@Suppress("unused")
class ResponseDecryptInterceptor(private val edApi: EncryptionDecryptionApi) : Interceptor {
    companion object {
        const val ERROR_CODE = 40001
        const val TAG = "ResponseDecryptInterceptor"
    }

    override fun intercept(chain: Interceptor.Chain): Response {

        val request = chain.request()
        val response = chain.proceed(request)

        val responseBody = response.body()
        val encodedPath = response.request().url().encodedPath()

        if (responseBody == null || !EDWhitePath.getWhitePath().contains(encodedPath)) {
            return response
        }

        // 开始解密
        return runCatching {
            decryptionResponseBody(responseBody, response)
        }.onFailure {
            // 异常说明解密失败 信息被篡改 直接返回即可
//            Logcat.error(TAG) { "解密异常 error: $it" }
            return response
        }.getOrDefault(response)

    }

    private fun decryptionResponseBody(responseBody: ResponseBody, response: Response): Response {
        val source = responseBody.source()
        source.request(Long.MAX_VALUE)
        val buffer = source.buffer()
        val bodyString = buffer.clone().readString(getCharset(responseBody))

        val responseData = edApi.wbDecryption(Base64.decode(bodyString, Base64.NO_WRAP))
        val realData = String(responseData.data ?: byteArrayOf())
        // 这里需要注意下，因为是网络库所以存在返回不一致的问题，有的可能返回{"code":40001,"message":"Key is invalid or expired"}
        // 有的可能返回{"resp_code": 40001,"resp_msg":"Key is invalid or expired"}
        updateWhiteBoxKey(response, realData)

        // 将解密后的明文返回
        return response.newBuilder().body(ResponseBody.create(responseBody.contentType(), realData))
            .build()
    }

    private fun getCharset(responseBody: ResponseBody): Charset {
        var charset = Charset.forName("UTF-8")
        val contentType = responseBody.contentType()
        if (contentType != null) {
            charset = contentType.charset(charset)
        }
        return charset
    }

    private fun updateWhiteBoxKey(response: Response, realData: String) {
        if (response.isSuccessful || !realData.contains("resp_code")) {
            return
        }
        val jsonObject = JSONObject(realData)
        val code: Int = jsonObject.get("resp_code") as Int

        if (code != ERROR_CODE) {
            return
        }
        // 如果错误吗是400001的时候说明白盒key是已经失效了，所以需要重新刷新白盒key
        // http code：400，body:{"resp_code": 40001,"resp_msg":"Key is invalid or expired"}

//        Logcat.warn(TAG) { "key失效需要刷新白盒key" }
        val whiteBoxKey = edApi.getWhiteBoxKey()
        if (!whiteBoxKey.isSuccessful()) {
//            Logcat.error(TAG) { "刷新白盒key失败 code:${whiteBoxKey.code}" }
        } else {
            edApi.upDateKey(whiteBoxKey.data?.wbKey, whiteBoxKey.data?.hmEkv)
        }
    }
}
