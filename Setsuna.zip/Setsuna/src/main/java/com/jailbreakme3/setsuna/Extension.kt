package com.jailbreakme3.setsuna

import android.util.Log
import okhttp3.Request
import java.util.*

private const val TAG = "Setsuna"

/**
 * 判断请求是否为post
 */
fun Request.isPost(): Boolean {
    return method().toLowerCase(Locale.ROOT).trim() == "post"
}

fun Any?.log() {
    Log.i(TAG, "$this")
}

fun Any?.log(tag: String) {
    Log.i(TAG, "$tag: $this")
}