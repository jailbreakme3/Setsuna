package com.jailbreakme3.setsuna.ednetwork

@Suppress("unused")
object EDWhitePath {
    private var whitePath = mutableSetOf<String>()

    fun addPath(path: String): EDWhitePath {
        whitePath.add(path)
        return this
    }

    fun removePath(path: String): EDWhitePath {
        if (whitePath.contains(path)) {
            whitePath.remove(path)
        }
        return this
    }

    fun getWhitePath(): Set<String> {
        return whitePath
    }
}