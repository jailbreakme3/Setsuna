package com.jailbreakme3.setsuna


import com.jailbreakme3.setsuna.helper.DownLoadHelper.Companion.downLoadTaskEnqueue
import com.jailbreakme3.setsuna.helper.DownLoadHelper.Companion.initDownload
import com.jailbreakme3.setsuna.listener.DownLoadListener
import com.jailbreakme3.setsuna.setsuna.SetsunaContext
import com.jailbreakme3.setsuna.setsuna.buildRequest
import com.jailbreakme3.setsuna.setsuna.buildRequestFull
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resumeWithException

/**
 * 执行网络接口请求
 *
 * 可在伪闭包中自定义请求内容
 */
fun http(requestBuilder: Request.Builder.() -> Unit): Response {
    val request = buildRequest { requestBuilder() }
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 执行网络接口请求
 *
 * 可在伪闭包中自定义请求内容
 */
fun http(request: Request): Response {
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 执行GET请求
 *
 * @param url 网络请求的url信息
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
fun httpGet(
    url: String,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val request = buildRequestFull(params, url, headers = headers)
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 执行POST请求
 *
 * @param url 网络请求的url信息
 * @param body post 具体内容
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
fun httpPost(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val request = buildRequestFull(params, url, body, headers, RequestType.POST)
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 执行PUT请求
 *
 * @param url 网络请求的url信息
 * @param body post 具体内容
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
@Suppress("unused")
fun httpPut(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val request = buildRequestFull(params, url, body, headers, RequestType.PUT)
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 执行DELETE请求
 *
 * @param url 网络请求的url信息
 * @param body post 具体内容
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
@Suppress("unused")
fun httpDelete(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val request = buildRequestFull(params, url, body, headers, RequestType.DELETE)
    return SetsunaContext.getClientOrDefault().call(request)
}

/**
 * 通过协程执行post请求
 *
 * @param body post 具体内容
 * @param url 网络请求的url信息
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
suspend fun awaitHttpPost(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val call =
        SetsunaContext.getClientOrDefault()
            .newCall(buildRequestFull(params, url, body, headers, RequestType.POST))
    return enqueueCall(call)
}

/**
 * 通过协程执行put请求
 *
 * @param body put 具体内容
 * @param url 网络请求的url信息
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
suspend fun awaitHttpPut(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val call = SetsunaContext.getClientOrDefault()
        .newCall(buildRequestFull(params, url, body, headers, RequestType.PUT))
    return enqueueCall(call)
}

/**
 * 通过协程执行delete请求
 *
 * @param body delete 具体内容
 * @param url 网络请求的url信息
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
suspend fun awaitHttpDelete(
    url: String,
    body: RequestBody,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val call =
        SetsunaContext.getClientOrDefault()
            .newCall(buildRequestFull(params, url, body, headers, RequestType.DELETE))
    return enqueueCall(call)
}

/**
 * 通过协程执行get请求
 *
 * @param url 网络请求的url信息
 * @param params 网络请求参数，默认为空
 * @param headers 网络请求的Header信息，默认为空
 */
@ExperimentalCoroutinesApi
suspend fun awaitHttpGet(
    url: String,
    params: Map<String, String> = mapOf(),
    headers: Map<String, String> = mapOf()
): Response {
    val call = SetsunaContext.getClientOrDefault()
        .newCall(buildRequestFull(params, url, headers = headers))
    return enqueueCall(call)
}

@ExperimentalCoroutinesApi
private suspend fun enqueueCall(call: Call): Response {
    return suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation {
            call.cancel()
        }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                continuation.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                continuation.resume(response) {

                }
            }
        })
    }
}

/**
 * 文件下载
 *
 * @receiver HttpKit
 * @param url String 下载地址
 * @param savePath String 保存路径
 * @param download [@kotlin.ExtensionFunctionType]
 * @return Call?，用于取消下载。取消下载会走完成回调，返回的path为null
 */
fun downloadFile(
    url: String,
    savePath: String,
    download: DownLoadListener.() -> Unit
): Call? {

    val (downloadListener, file) = initDownload(download, savePath)
    val call = runCatching {
        SetsunaContext.getClientOrDefault().newCall(buildRequestFull(url = url))
    }.onFailure {
        downloadListener.failed?.invoke(it)
        return null
    }

    downLoadTaskEnqueue(call.getOrNull()!!, downloadListener, file, savePath, url)
    return call.getOrNull()
}
