package com.jailbreakme3.setsuna.interceptor

import okhttp3.Interceptor
import okhttp3.Response
import java.util.*

/**
 * 用于添加全局header
 */

class HeaderInterceptor(private val header: () -> MutableMap<String, String>) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val requestBuilder = original.newBuilder()
        for ((key, value) in header.invoke()) {
            requestBuilder.addHeader(key, value)
        }
        requestBuilder.addHeader("X-Request-Id", UUID.randomUUID().toString())
        val request = requestBuilder.build()
        return chain.proceed(request)
    }

}