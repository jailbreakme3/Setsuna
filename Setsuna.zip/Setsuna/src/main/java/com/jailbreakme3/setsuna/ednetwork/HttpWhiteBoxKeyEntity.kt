package com.jailbreakme3.setsuna.ednetwork

/**
 * @param hmEkv IV文本，在CBC模式下需要上传AQAAAAAAAABNAgAABOMsSGGyFEoKRutNkHM
 * @param wbKey 白盒key
 */
data class HttpWhiteBoxKeyEntity(val hmEkv: String?, val wbKey: String?)