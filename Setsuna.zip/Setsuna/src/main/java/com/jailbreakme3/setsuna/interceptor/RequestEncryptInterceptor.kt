package com.jailbreakme3.setsuna.interceptor


import android.util.Base64
import android.util.Log
import com.jailbreakme3.setsuna.ednetwork.EDWhitePath
import com.jailbreakme3.setsuna.ednetwork.EncryptionDecryptionApi
import com.jailbreakme3.setsuna.isPost
import okhttp3.Interceptor
import okhttp3.MediaType
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import okio.Buffer
import java.nio.charset.Charset

/**
 * 对请求数据进行加密处理
 */
@Suppress("unused")
class RequestEncryptInterceptor(private val edApi: EncryptionDecryptionApi) : Interceptor {
    companion object {
        const val TAG = "RequestEncryptInterceptor"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        // 请求接口的path
        val encodedPath = request.url().encodedPath()
        val requestBody = request.body()

        // 判断请求体是否为空  不为空则执行以下操作
        // 如果请求方式是Post，则请求数据在请求体中
        // 如果请求的不是服务端的接口，不加密
        if (!request.isPost() || requestBody == null || !EDWhitePath.getWhitePath().contains(encodedPath)) {
            return chain.proceed(request)
        }

        // 获取请求的数据
        request = runCatching {
            encryptionRequestBody(requestBody, getCharset(requestBody), requestBody.contentType(), addRequestHeader(chain))
        }.onFailure {
            Log.e("", "加密异常 error: $it")
            return chain.proceed(request)
        }.getOrDefault(request)

        return chain.proceed(request)
    }

    private fun addRequestHeader(chain: Interceptor.Chain): Request {
        val request = chain.request()
        val newBuilder = request.newBuilder()
        newBuilder.addHeader("X-HM-EKV", edApi.getHmKv())
        return newBuilder.build()
    }

    private fun getCharset(requestBody: RequestBody): Charset {
        var charset = Charset.forName("UTF-8")
        val contentType = requestBody.contentType()
        if (contentType != null) {
            charset = contentType.charset(charset)
        }
        return charset
    }

    private fun encryptionRequestBody(
        requestBody: RequestBody,
        charset: Charset,
        contentType: MediaType?,
        request: Request
    ): Request {
        val buffer = Buffer()
        requestBody.writeTo(buffer)
        val trim = buffer.readString(charset).trim()
        val encryptData = edApi.wbEncryption(trim.toByteArray())
        val encodeToString = Base64.encodeToString(encryptData.data, Base64.NO_WRAP)
        // 构建新的请求体
        val newRequestBody = RequestBody.create(
            contentType,
            encodeToString
        )
        // 构建新的requestBuilder
        val newRequestBuilder = request.newBuilder().post(newRequestBody)
        return newRequestBuilder.build()
    }
}
