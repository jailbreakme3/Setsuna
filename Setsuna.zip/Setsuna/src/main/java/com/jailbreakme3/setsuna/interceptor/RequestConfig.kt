package com.jailbreakme3.setsuna.interceptor

import okhttp3.Interceptor
import okhttp3.logging.HttpLoggingInterceptor

/**
 * 提供通用OkHttp拦截器
 * @return List<Interceptor>
 */
fun getOkHttpInterceptors(): List<Interceptor> {
    return mutableListOf<Interceptor>().apply {
        add(HeaderInterceptor {
            getRequestHeader().invoke()
        })
    }
}

/**
 * 提供通用OkHttp网络拦截器
 * @return List<Interceptor>
 */
fun getGlobalOkHttpNetworkInterceptors(tag: String): List<Interceptor> {
    return mutableListOf<Interceptor>().apply {
//        add(RequestEncryptInterceptor())
        // 对于需要加密的请求(详看RequestEncryptInterceptor的白名单)，既请求的安全级别高，需要保证落盘也是加密状态
        // 既：LogcatInterceptor需要放在RequestEncryptInterceptor之后
        add(logcatInterceptor(tag))
    }
}

/**
 * 包含请求token的通用请求头
 * @return () -> MutableMap<String, String>
 */
fun getRequestHeader(): () -> MutableMap<String, String> {
    return {
        runCatching {
            //
            mutableMapOf<String, String>()
        }.onFailure {
            it.printStackTrace()
        }.getOrDefault(mutableMapOf())
    }
}

/**
 * CurlInterceptor拦截器
 * 建议：放到Request Chain最后，目的在于获取最完整curl信息
 * @param tag String
 * @return CurlInterceptor
 */
private fun curlInterceptor(tag: String): CurlInterceptor {
    return CurlInterceptor()
}


/**
 * 官方HttpLoggingInterceptor，查看请求日志（调试时使用）
 * @param tag String
 * @return HttpLoggingInterceptor
 */
private fun httpLoggingInterceptor(tag: String): HttpLoggingInterceptor {
    return HttpLoggingInterceptor { message ->
//        HMLog.info(tag) { message }
    }.setLevel(HttpLoggingInterceptor.Level.BODY)
}

/**
 * 记录请求信息，用于排查线上问题
 * @param tag String
 * @return LogcatInterceptor
 */
private fun logcatInterceptor(tag: String): LogcatInterceptor {
    return LogcatInterceptor(object : LogcatInterceptor.Logger {
        override fun log(message: String) {
//            HMLog.info(tag) { message }
        }
    })
}
