package com.jailbreakme3.setsuna


import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import okio.BufferedSink
import okio.source
import org.json.JSONObject
import java.io.InputStream

/**
 * 通过Map 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 * Map会转成对应Json String
 * eg.
 * mapOf("name" to "张三", "age" to 18, "males" to true)
 * {"name":"张三","age":18,"males":true}
 */
@Suppress("unused")
fun buildRequestJsonBody(map: Map<String, Any>): RequestBody {
    val json = JSONObject()
    for ((key, value) in map) {
        json.put(key, value)
    }
    return RequestBody.create(MediaType.parse("application/json"), json.toString())
}

/**
 * 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 */
@Suppress("unused")
fun buildRequestJsonBody(vararg kvs: Pair<String, String>): RequestBody {
    val json = JSONObject()
    for ((key, value) in kvs) {
        json.put(key, value)
    }
    return RequestBody.create(MediaType.parse("application/json"), json.toString())
}

/**
 * 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 */
@Suppress("unused")
fun buildRequestJsonBody(body: String): RequestBody {
    return RequestBody.create(MediaType.parse("application/json"), body)
}

/**
 * 构建 OkHttp网络库的 [okhttp3.FormBody] 对象
 */
@Suppress("unused")
inline fun buildRequestFormBody(block: FormBody.Builder.() -> Unit): FormBody {
    return FormBody.Builder().apply {
        block()
    }.build()
}

/**
 * 构建 OkHttp网络库的 [okhttp3.MultipartBody] 对象
 */
@Suppress("unused")
inline fun buildRequestMultipartBody(boundary: String? = null, block: MultipartBody.Builder.() -> Unit): MultipartBody {
    val builder = if (boundary == null) {
        MultipartBody.Builder()
    } else {
        MultipartBody.Builder(boundary)
    }
    return builder.apply {
        block()
    }.build()
}

/**
 * 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 *
 * MediaType 为 application/octet-stream
 */
@Suppress("unused")
inline fun buildRequestStreamBody(crossinline writeToBlock: (sink: BufferedSink) -> Unit): RequestBody {
    return object : RequestBody() {
        override fun contentType(): MediaType? {
            return MediaType.get("application/octet-stream")
        }

        override fun writeTo(sink: BufferedSink) {
            writeToBlock(sink)
        }
    }
}

/**
 * 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 *
 * MediaType 为 application/octet-stream
 */
@Suppress("unused")
fun buildRequestStreamBody(input: InputStream): RequestBody {
    return object : RequestBody() {
        override fun contentType(): MediaType? {
            return MediaType.get("application/octet-stream")
        }

        override fun writeTo(sink: BufferedSink) {
            sink.writeAll(input.source())
        }
    }
}

/**
 * 构建 OkHttp网络库的 [okhttp3.RequestBody] 对象
 *
 * MediaType 为 application/octet-stream
 */
@Suppress("unused")
fun buildRequestStreamBody(
    type: String = "application/octet-stream",
    content: ByteArray,
    offset: Int = 0,
    byteCount: Int = content.count()
): RequestBody {
    return RequestBody.create(MediaType.parse(type), content, offset, byteCount)
}

/**
 * 创建一下新的 HttpUrl 对象
 *
 * @param block
 */
fun HttpUrl.newHttpUrl(url: String? = null, block: (HttpUrl.Builder.() -> Unit)? = null): HttpUrl {
    val builder = if (url == null) {
        newBuilder()
    } else {
        newBuilder(url) ?: newBuilder()
    }
    return builder.apply {
        block?.invoke(this)
    }.build()
}


/**
 * 执行网络请求
 *
 * @param request 网络请求信息
 */
fun OkHttpClient.call(request: Request): Response {
    return newCall(request).execute()
}
