package com.jailbreakme3.setsuna.ednetwork

interface EncryptionDecryptionApi {
    /**
     * 加密接口
     */
    fun wbEncryption(date: ByteArray): HttpDeResponse<ByteArray>

    /**
     * 解密接口
     */
    fun wbDecryption(date: ByteArray): HttpDeResponse<ByteArray>

    /**
     * 刷新白盒key接口
     */
    fun getWhiteBoxKey(): HttpDeResponse<HttpWhiteBoxKeyEntity>

    /**
     * 把新的key刷新到app的date数据里
     */
    fun upDateKey(webKey: String?, hmKv: String?)

    /**
     * 获取hmkv参数，方便在白名单的接口调用的时候封装到header请求头里
     */
    fun getHmKv(): String
}